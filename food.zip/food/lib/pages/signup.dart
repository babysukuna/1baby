import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:food/pages/bottom.dart';
import 'package:food/pages/login.dart';
import 'package:food/widget/widget.dart';
import 'package:food/pages/firestore.dart';
class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State <Signup> createState() => SignupState();
}

class SignupState extends State <Signup> {

  String email="", password="", name="";

  TextEditingController namecontroller = new TextEditingController();
  TextEditingController passwordcontroller = new TextEditingController();
  TextEditingController mailcontroller = new TextEditingController();

  final _formkey= GlobalKey<FormState>();

  registration() async {
  try {
    UserCredential userCredential = await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password);

    final uid = userCredential.user!.uid;

    // Firestore-д хэрэглэгчийн мэдээлэл хадгалах
    await FirestoreService().addUserToFirestore(
      uid: uid,
      name: name,
      email: email,
    );

    // Амжилттай бүртгэгдсэн мэдэгдэл
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text("Амжилттай бүртгүүллээ", style: TextStyle(fontSize: 20.0)),
      ),
    );

    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => Bottom()));
  } on FirebaseAuthException catch (e) {
    if (e.code == 'weak-password') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.amber,
          content: Text("Нууц үг хэтэрхий сул байна", style: TextStyle(fontSize: 18.0)),
        ),
      );
    } else if (e.code == 'email-already-in-use') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.amber,
          content: Text("Энэ имэйл аль хэдийн ашиглагдаж байна", style: TextStyle(fontSize: 18.0)),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Алдаа гарлаа: ${e.message}", style: TextStyle(fontSize: 18.0)),
        ),
      );
    }
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
             Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height/2.5,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                    Color.fromARGB(255, 0, 153, 255),
                    Color.fromARGB(255, 0, 153, 255),
                  ])),
            ),
            Container(
              margin: EdgeInsets.only(top: MediaQuery.of(context).size.height/3), 
              height: MediaQuery.of(context).size.height/1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(color: const Color.fromARGB(255, 255, 255, 255),borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))),
              child: Text(""),
            ),
            Container(
              margin: EdgeInsets.only(top: 10.0, left: 20.0, right: 20.0),
              child: Column(
                children: [
                  Center(
                      child: Image.asset(
                    "images/logo.png",color: Colors.black,
                    width: MediaQuery.of(context).size.width / 1.5,
                    fit: BoxFit.cover,
                  )),
                  Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: EdgeInsets.only(left: 30.0,right: 30.0),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height/1.8,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
                      child: Form(
                        key: _formkey,
                        child: Column(children: [
                          SizedBox(height: 30.0,),
                        Text("Бүртгүүлнэ үү",
                        style: AppWidget.HeadLineTextFeildStyle(),),
                        SizedBox(height: 30.0,),
                        TextFormField(
                          controller: namecontroller,
                          validator: (value){
                            if(value==null || value.isEmpty){
                              return 'Нэр оруулна уу';
                            }
                            return null;
                          },
                          decoration: InputDecoration(hintText: 'Нэр',hintStyle: AppWidget.LightTextFeildStyle(),prefixIcon:Icon(Icons.person_outlined)),
                        ),
                        SizedBox(height: 30.0,),
                        TextFormField(
                          controller: mailcontroller,
                          validator: (value){
                            if(value==null || value.isEmpty){
                              return 'Имэйл оруулна уу';
                            }
                            return null;
                          },
                          decoration: InputDecoration(hintText: 'Имэйл',hintStyle: AppWidget.LightTextFeildStyle(),prefixIcon:Icon(Icons.email_outlined)),
                        ),
                          SizedBox(height: 30.0,),
                        TextFormField(
                          controller: passwordcontroller,
                          validator: (value){
                            if(value==null || value.isEmpty){
                              return 'Нууц үг оруулна уу';
                            }
                            return null;
                          },
                          obscureText: true,
                          decoration: InputDecoration(hintText: 'Нууц үг',hintStyle: AppWidget.LightTextFeildStyle(),prefixIcon:Icon(Icons.password_outlined)),
                        ),
                        SizedBox(height: 30.0,),
                        GestureDetector(
                          onTap: () async {
  if (_formkey.currentState!.validate()) {
    setState(() {
      email = mailcontroller.text;
      name = namecontroller.text;
      password = passwordcontroller.text;
    });
    await registration(); 
  }
},

                          child: Material(
                            borderRadius: BorderRadius.circular(20.0),
                            elevation: 9.0,
                            child: Container( 
                              padding: EdgeInsets.symmetric(vertical: 8.0),
                              width: 200,
                              decoration: BoxDecoration(color:Color.fromARGB(255, 0, 153, 255),borderRadius: BorderRadius.circular(20.0)),
                              child: Center(child: Text("Бүртгүүлэх", style: TextStyle(color: const Color.fromARGB(255, 255, 255, 255),fontSize: 15.0, fontFamily: 'Poppins1',fontWeight: FontWeight.bold),)),
                            ),
                          ),
                        ),   
                                            ],),
                      ),),   
                  ),   
                  SizedBox(height: 70.0,),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> Login()));
                    },
                    child: Text("Аль хэдийн бүртгэлтэй байна уу? Нэвтрэх",style: AppWidget.SemiBoldTextFeildStyle(),)),
              ],),

            )
          ],
        ),
      ),
    );
  }
}
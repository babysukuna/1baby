import 'package:flutter/material.dart';
import 'package:food/widget/widget.dart'; 
import 'details.dart';  

class IceCreamTab extends StatelessWidget {
  const IceCreamTab({super.key});

  final List<Map<String, dynamic>> iceCreams = const [
    {
      "image": "images/ice-cream1.png",
      "title": "Чихэрлэг зайрмаг",
      "subtitle": "Гүзээлзгэнэтэй, сүүтэй",
      "price": 9000,
      "description": """
Чихэрлэг зайрмаг нь халуун зун цагт сэрүүцүүлэх хамгийн тохиромжтой амттан бөгөөд төрөл бүрийн жимс, шоколад, ваниль зэрэг амттайгаар хийгддэг. 
Энэхүү зайрмаг нь өтгөн бүтэцтэй, сүү, цөцгий, сахар зэргийг агуулсан тул аманд ороход зөөлөн, амтлаг мэдрэмж төрүүлдэг. 
Жижиг хүүхдээс эхлээд насанд хүрэгчид хүртэл дуртай байдаг бөгөөд баяр ёслол, чөлөөт цагийн үеэр өргөн хэрэглэгддэг. 
Манай зайрмаг нь байгалийн гаралтай орц найрлагатай бөгөөд нэмэлт үнэр, амт оруулагчгүй тул эрүүл мэндэд сөрөг нөлөөгүй. 
Хадгалалтын онцгой нөхцөлд чанараа удаан хадгалах чадвартай.
"""
    },
    {
      "image": "images/ice-cream2.png",
      "title": "Шоколадтай зайрмаг",
      "subtitle": "Хар шоколадны амттай",
      "price": 9500,
      "description": """
Шоколадтай зайрмаг нь тансаг, гүн амттай бөгөөд хар шоколадны баялаг амтыг агуулсан байдаг. 
Хар шоколад нь антиоксидантаар баялаг тул зөвхөн амттай төдийгүй биед эерэг нөлөө үзүүлдэг. 
Манай шоколадтай зайрмаг нь жинхэнэ какао ашиглан хийгдсэн бөгөөд элдэв нэмэлт бодис агуулаагүй. 
Өтгөн бүтэцтэй, шингэхгүй хайлдаггүй тул халуун өдөр идэхэд төгс сонголт. 
Баяр ёслолын үеэр ч, өдөр тутмын амралтын хором бүрийг чимэх амттан юм.
"""
    }
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20.0),
          Text("Зайрмаг", style: AppWidget.HeadLineTextFeildStyle()),
          Text("Сэтгэл татам амттай зайрмаг", style: AppWidget.LightTextFeildStyle()), 
          const SizedBox(height: 20.0),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: iceCreams.map((iceCream) {
                return Padding(
                  padding: const EdgeInsets.only(right: 15.0),
                  child: _buildIceCreamCard(
                    context,
                    image: iceCream["image"],
                    title: iceCream["title"],
                    subtitle: iceCream["subtitle"],
                    price: iceCream["price"],
                    description: iceCream["description"],
                  ),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 30.0),

          // Vertical cards
          Column(
            children: iceCreams.map((iceCream) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 20.0),
                child: _buildIceCreamCardVertical(
                  context,
                  image: iceCream["image"],
                  title: iceCream["title"],
                  subtitle: iceCream["subtitle"],
                  price: iceCream["price"],
                  description: iceCream["description"],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildIceCreamCard(
    BuildContext context, {
    required String image,
    required String title,
    required String subtitle,
    required int price,
    required String description,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Details(
              image: image,
              title: title,
              subtitle: subtitle,
              price: price,
              description: description,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.all(4),
        child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(image, height: 150, width: 150, fit: BoxFit.cover),
                const SizedBox(height: 8),
                Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                const SizedBox(height: 5.0),
                Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                const SizedBox(height: 5.0),
                Text("₮$price", style: AppWidget.SemiBoldTextFeildStyle()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIceCreamCardVertical(
    BuildContext context, {
    required String image,
    required String title,
    required String subtitle,
    required int price,
    required String description,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Details(
              image: image,
              title: title,
              subtitle: subtitle,
              price: price,
              description: description,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(right: 20.0),
        child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(10),
          child: Container(
            padding: const EdgeInsets.all(5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(image, height: 120, width: 120, fit: BoxFit.cover),
                const SizedBox(width: 20.0),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                      const SizedBox(height: 5.0),
                      Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                      const SizedBox(height: 5.0),
                      Text("₮$price", style: AppWidget.SemiBoldTextFeildStyle()),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

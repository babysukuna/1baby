import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:food/pages/bottom.dart';
import 'package:food/pages/signup.dart';
import 'package:food/widget/widget.dart';
import 'package:food/pages/home.dart'; 

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {

String email="", password="";

final _formkey = GlobalKey<FormState>();

TextEditingController useremailcontroller = new TextEditingController();
TextEditingController userpasswordcontroller = new TextEditingController();
userLogin() async {
  try {
    await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text("Амжилттай нэвтэрлээ", style: TextStyle(fontSize: 18.0)),
      ),
    );

    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> Bottom()));
  } on FirebaseAuthException catch (e) {
    if (e.code == 'user-not-found') {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Энэ имэйлд хэрэглэгч олдсонгүй",
            style: TextStyle(fontSize: 18.0, color: Colors.black)),
      ));
    } else if (e.code == 'wrong-password') {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Хэрэглэгчийн оруулсан нууц үг буруу",
            style: TextStyle(fontSize: 18.0, color: Colors.black)),
      ));
    }
  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
             Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height/2.5,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                    Color.fromARGB(255, 0, 153, 255),
                    Color.fromARGB(255, 0, 153, 255),
                  ])),
            ),
            Container(
              margin: EdgeInsets.only(top: MediaQuery.of(context).size.height/3), 
              height: MediaQuery.of(context).size.height/1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(color: const Color.fromARGB(255, 255, 255, 255),borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))),
              child: Text(""),
            ),
            Container(
              margin: EdgeInsets.only(top: 10.0, left: 20.0, right: 20.0),
              child: Column(
                children: [
                  Center(
                      child: Image.asset(
                    "images/logo.png",color: Colors.black,
                    width: MediaQuery.of(context).size.width / 1.5,
                    fit: BoxFit.cover,
                  )),
                  Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: EdgeInsets.only(left: 30.0,right: 30.0),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height/1.8,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
                      child: Form(
                        key: _formkey,
                        child: Column(children: [
                          SizedBox(height: 30.0,),
                        Text("Нэврэх",
                        style: AppWidget.HeadLineTextFeildStyle(),),
                        SizedBox(height: 30.0,),
                        TextFormField(
                          controller: useremailcontroller,
                          validator: (value){
                            if(value==null || value.isEmpty){
                              return 'Имэйл оруулна уу';
                            }
                            return null;
                          },
                          decoration: InputDecoration(hintText: 'Имэйл',hintStyle: AppWidget.LightTextFeildStyle(),prefixIcon:Icon(Icons.email_outlined)),
                        ),
                          SizedBox(height: 30.0,),
                        TextFormField(
                          controller: userpasswordcontroller,
                          validator: (value){
                            if(value==null || value.isEmpty){
                              return 'Нууц үгээ оруулна уу';
                            }
                            return null;
                          },
                          obscureText: true,
                          decoration: InputDecoration(hintText: 'Нууц үг',hintStyle: AppWidget.LightTextFeildStyle(),prefixIcon:Icon(Icons.password_outlined)),
                        ),
                        SizedBox(height: 20.0,),
                        Container(
                        alignment: Alignment.topRight,
                        child: Text("Нууц үгээ мартсан уу?",style: AppWidget.SemiBoldTextFeildStyle(),)),
                        SizedBox(height: 70.0,),
                        GestureDetector(
                          onTap: (){
                            if(_formkey.currentState!.validate()){
                              setState(() {
                                email = useremailcontroller.text;
                                password = userpasswordcontroller.text;
                              });
                              userLogin();
                            }
                            
                          },
                          child: Material(
                            borderRadius: BorderRadius.circular(20.0),
                            elevation: 5.0,
                            child: Container( 
                              padding: EdgeInsets.symmetric(vertical: 8.0),
                              width: 200,
                              decoration: BoxDecoration(color:Color.fromARGB(255, 0, 153, 255),borderRadius: BorderRadius.circular(20.0)),
                              child: Center(child: Text("НЭВТРЭХ", style: TextStyle(color: const Color.fromARGB(255, 255, 255, 255),fontSize: 18.0, fontFamily: 'Poppins1',fontWeight: FontWeight.bold),)),
                            ),
                          ),
                        ),   
                                            ],),
                      ),),   
                  ),   
                  SizedBox(height: 70.0,),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> Signup()));
                    },
                    child: Text("Хаяг байхгүй юу? Бүртгүүлэх",style: AppWidget.SemiBoldTextFeildStyle(),)),
              ],),

            )
          ],
        ),
      ),
    );
  }
}
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addUserToFirestore({
    required String uid,
    required String name,
    required String email,
    int wallet = 0,
  }) async {
    await _firestore.collection('users').doc(uid).set({
      'id': uid,
      'name': name,
      'email': email,
      'wallet': wallet,
    });
  }
}

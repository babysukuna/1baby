import 'package:flutter/material.dart';
import 'package:food/widget/widget.dart'; 
import 'details.dart';

class BurgerTab extends StatelessWidget {
  const BurgerTab({super.key});

  final List<Map<String, dynamic>> burgers = const [
    {
      "image": "images/burger11.png",
      "title": "Чийз бургер",
      "subtitle": "Бяслагтай амттай бургер",
      "price": 18000,
      "description": """
Чийз бургер нь зөөлөн талх, хайлсан бяслаг болон шинэхэн махны амттай хослол бөгөөд төрөл бүрийн амтлагч, ногоотой хослуулан бэлтгэдэг.
Хооллохдоо амтлаг, өег байдлыг мэдрүүлж, хурдан хооллоход тохиромжтой.
"""
    },
    {
      "image": "images/burger2.png",
      "title": "Double Burger",
      "subtitle": "Хоёр давхар махтай",
      "price": 22000,
      "description": """
Double Burger нь хоёр давхар махны ширхэгтэй, илүү их махны амтыг хүсэгчдэд зориулагдсан.
Өргөн цар хүрээтэй амтлагч болон ногоотой хослуулан, махан хоолонд дурлагчдын сонголт юм.
"""
    }
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20.0),
          Text("Бургерууд", style: AppWidget.HeadLineTextFeildStyle()),
          Text("Амтат бургерээс сонгоорой", style: AppWidget.LightTextFeildStyle()),
          const SizedBox(height: 20.0),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: burgers.map((burger) {
                return Padding(
                  padding: const EdgeInsets.only(right: 15.0),
                  child: _buildBurgerCard(
                    context,
                    image: burger["image"],
                    title: burger["title"],
                    subtitle: burger["subtitle"],
                    price: burger["price"],
                    description: burger["description"],
                  ),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 30.0),

          Column(
            children: burgers.map((burger) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 20.0),
                child: _buildBurgerCardVertical(
                  context,
                  image: burger["image"],
                  title: burger["title"],
                  subtitle: burger["subtitle"],
                  price: burger["price"],
                  description: burger["description"],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildBurgerCard(
    BuildContext context, {
    required String image,
    required String title,
    required String subtitle,
    required int price,
    required String description,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Details(
              image: image,
              title: title,
              subtitle: subtitle,
              price: price,
              description: description,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.all(4),
        child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(image, height: 150, width: 150, fit: BoxFit.cover),
                const SizedBox(height: 8),
                Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                const SizedBox(height: 5.0),
                Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                const SizedBox(height: 5.0),
                Text("₮$price", style: AppWidget.SemiBoldTextFeildStyle()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBurgerCardVertical(
    BuildContext context, {
    required String image,
    required String title,
    required String subtitle,
    required int price,
    required String description,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Details(
              image: image,
              title: title,
              subtitle: subtitle,
              price: price,
              description: description,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(right: 20.0),
        child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(10),
          child: Container(
            padding: const EdgeInsets.all(5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(image, height: 120, width: 120, fit: BoxFit.cover),
                const SizedBox(width: 20.0),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                      const SizedBox(height: 5.0),
                      Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                      const SizedBox(height: 5.0),
                      Text("₮$price", style: AppWidget.SemiBoldTextFeildStyle()),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

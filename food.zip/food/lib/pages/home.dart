import 'package:flutter/material.dart';
import 'package:food/pages/allFoodTab.dart';
import 'package:food/pages/burger.dart';
import 'package:food/pages/dumpling.dart';
import 'package:food/pages/ice-cream.dart';
import 'package:food/pages/pizza.dart';
import 'package:food/widget/widget.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text("Сайн уу Бамбуу,", style: AppWidget.boldTextFieldStyle()),
          bottom: TabBar(
            controller: _tabController,
            labelColor: Colors.black,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.transparent,
            tabs: [
              const Tab(icon: Icon(Icons.home_outlined)),
              _buildTabIcon("images/burger.png", 1),
              _buildTabIcon("images/dumpling.png", 2),
              _buildTabIcon("images/pizza.png", 3),
              _buildTabIcon("images/ice-cream.png", 4),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: const [
            AllFoodTab(),
            BurgerTab(),
            DumplingTab(),
            PizzaTab(),
            IceCreamTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildTabIcon(String imagePath, int tabIndex) {
    return AnimatedBuilder(
      animation: _tabController.animation!,
      builder: (context, child) {
        final bool isSelected = _tabController.index == tabIndex;
        return Tab(
          child: Material(
            elevation: isSelected ? 6.0 : 2.0,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              decoration: BoxDecoration(
                color: isSelected ? Colors.black : Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(6),
              child: Image.asset(
                imagePath,
                width: 30,
                height: 30,
                fit: BoxFit.cover,
                color: isSelected ? Colors.white : Colors.black,
              ),
            ),
          ),
        );
      },
    );
  }
}

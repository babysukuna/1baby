import 'package:flutter/material.dart';
import 'package:food/widget/widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Wallet extends StatefulWidget {
  const Wallet({super.key});

  @override
  State<Wallet> createState() => _WalletState();
}

class _WalletState extends State<Wallet> {
  TextEditingController amountcontroller = TextEditingController();
  bool showAddMoney = false;
  int balance = 0;

  @override
  void initState() {
    super.initState();
    getBalance();
  }

  void getBalance() async {
  try {
    final String uid = FirebaseAuth.instance.currentUser!.uid;
    var doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (doc.exists && doc.data()!.containsKey('wallet')) {
      setState(() {
        balance = doc['wallet'];
      });
    }
  } catch (e) {
    print('Баланс уншиж чадсангүй ээ: $e');
  }
}


  void addMoney() async {
  String text = amountcontroller.text;
  int? enteredAmount = int.tryParse(text);
  if (enteredAmount != null && enteredAmount > 0) {
    final String uid = FirebaseAuth.instance.currentUser!.uid;

    try {
      
      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'wallet': FieldValue.increment(enteredAmount),
      });

      setState(() {
        balance += enteredAmount;
        amountcontroller.clear();
        showAddMoney = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Амжилттай цэнэглэлээ")),
      );
    } catch (e) {
      print('Firebase-д хадгалах үед алдаа гарлаа: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Алдаа гарлаа")),
      );
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Зөв хэмжээ оруулна уу")),
    );
  }
}


  @override
  void dispose() {
    amountcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.only(top: 60.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Material(
              elevation: 2.0,
              child: Container(
                padding: EdgeInsets.only(bottom: 10.0),
                child: Center(
                  child: Text(
                    "Хэтэвч",
                    style: AppWidget.HeadLineTextFeildStyle(),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30.0),
            Container(
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(color: Color.fromARGB(15, 252, 106, 2)),
              child: Row(
                children: [
                  Image.asset(
                    "images/wallet-icon-on-transparent-background-free-png.webp",
                    height: 50,
                    width: 50,
                    fit: BoxFit.cover,
                  ),
                  SizedBox(width: 40.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Таны хэтэвч", style: AppWidget.LightTextFeildStyle()),
                      SizedBox(height: 5.0),
                      Text("₮$balance", style: AppWidget.boldTextFieldStyle()),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(height: 20.0),
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Text("Цэнэглэх", style: AppWidget.SemiBoldTextFeildStyle()),
            ),
            SizedBox(height: 10.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                amountBox("₮5000"),
                amountBox("₮10000"),
                amountBox("₮20000"),
                amountBox("₮25000"),
              ],
            ),
            SizedBox(height: 50.0),
            GestureDetector(
              onTap: () {
                setState(() {
                  showAddMoney = !showAddMoney;
                });
              },
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 20.0),
                padding: EdgeInsets.symmetric(vertical: 12.0),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 27, 204, 221),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    showAddMoney ? "Нууцлах" : "Цэнэглэх",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17.0,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            if (showAddMoney)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Цэнэглэх",
                      style: TextStyle(
                        color: Color(0xFF008080),
                        fontWeight: FontWeight.bold,
                        fontSize: 16.0,
                      ),
                    ),
                    SizedBox(height: 10.0),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 10.0),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black38, width: 2.0),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextField(
                        controller: amountcontroller,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Дүнгээ оруулна уу',
                        ),
                      ),
                    ),
                    SizedBox(height: 10.0),
                    ElevatedButton(
                      onPressed: addMoney,
                      child: Text("Хийх"),
                    )
                  ],
                ),
              )
          ],
        ),
      ),
    );
  }

  Widget amountBox(String amount) {
    return GestureDetector(
      onTap: () {
        String numericAmount = amount.replaceAll("₮", "");
        amountcontroller.text = numericAmount;
      },
      child: Container(
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
          border: Border.all(color: Color(0xFFE9E2E2)),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          amount,
          style: AppWidget.SemiBoldTextFeildStyle(),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:food/widget/widget.dart';

class Details extends StatefulWidget {
  final String image;
  final String title;
  final String subtitle;
  final int price;
  final String description;

  const Details({
    required this.image,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.description,
    super.key,
  });

  @override
  State<Details> createState() => _DetailsState();
}

class _DetailsState extends State<Details> {
  int quantity = 1;

  @override
  Widget build(BuildContext context) {
    int totalPrice = quantity * widget.price;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.arrow_back_ios_new_outlined, color: Colors.black),
              ),
              const SizedBox(height: 20.0),
              Image.asset(
                widget.image,
                width: double.infinity,
                height: MediaQuery.of(context).size.height / 2.5,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 20.0),
              Text(widget.title, style: AppWidget.boldTextFieldStyle()),
              Text(widget.subtitle, style: AppWidget.LightTextFeildStyle()),
              const SizedBox(height: 10.0),
              Text("₮${widget.price}", style: AppWidget.SemiBoldTextFeildStyle()),
              const SizedBox(height: 20.0),
              Text(widget.description, style: AppWidget.LightTextFeildStyle()),
              const SizedBox(height: 20.0),

              Row(
                children: [
                  Row(
                    children: [
                      Text("Хүргэх хугацаа", style: AppWidget.SemiBoldTextFeildStyle()),
                      const SizedBox(width: 25.0),
                      const Icon(Icons.alarm, color: Colors.black54),
                      const SizedBox(width: 5.0),
                      Text("30 мин", style: AppWidget.SemiBoldTextFeildStyle()),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove, color: Colors.black),
                        onPressed: () {
                          if (quantity > 1) {
                            setState(() {
                              quantity--;
                            });
                          }
                        },
                      ),
                      Text(
                        '$quantity',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: const Icon(Icons.add, color: Colors.black),
                        onPressed: () {
                          setState(() {
                            quantity++;
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 30.0),
              Container(
                margin: const EdgeInsets.only(bottom: 40.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Нийт үнэ", style: AppWidget.SemiBoldTextFeildStyle()),
                        Text("₮$totalPrice", style: AppWidget.HeadLineTextFeildStyle()),
                      ],
                    ),
                    GestureDetector(
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Сагсанд нэмэгдлээ!")),
                        );
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.5,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text("Сагсанд нэмэх", style: TextStyle(color: Colors.white, fontSize: 16.0)),
                            SizedBox(width: 10.0),
                            Icon(Icons.shopping_cart_outlined, color: Colors.white),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

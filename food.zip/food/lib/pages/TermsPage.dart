import 'package:flutter/material.dart';

class TermsPage extends StatelessWidget {
  const TermsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Нөхцөл ба болзол'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Нөхцөл ба болзол',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
            Text(
        'Аппын Нөхцөл ба Болзол\n\n'
         'Манай аппыг ашигласнаар та дараах нөхцөл, болзлыг зөвшөөрч байна:\n\n'
        '- Бүртгэл: Аппыг бүрэн ашиглахын тулд хэрэглэгч бүртгэл үүсгэх шаардлагатай.\n'
         '- Лиценз: Аппын бүх агуулга нь зохиогчийн эрхийн хамгаалалтад хамаарна. Хувийн хэрэгцээнээс бусад зорилгоор ашиглахыг хориглоно.\n'
       '- Хувийн мэдээлэл: Хэрэглэгчийн өгсөн мэдээллийг бид нууцлалын бодлогын дагуу хамгаална.\n'
         '- Хэрэглэгчийн үүрэг: Та аппыг хууль ёсны, зохистой аргаар ашиглах ёстой.\n'
         '- Үйлчилгээний нөхцөл: Аппын зарим үйлчилгээг бид тодорхой хугацаанд өөрчилж, сайжруулж болох бөгөөд энэ нь хэрэглэгчдэд шууд мэдэгдэнэ.\n\n'
           'Хэрвээ та эдгээр нөхцөлтэй санал нийлэхгүй бол аппыг ашиглах боломжгүйг анхаарна уу.',
       style: TextStyle(fontSize: 16),
      ),

            ],
          ),
        ),
      ),
    );
  }
}

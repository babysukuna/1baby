import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:food/pages/SharedPreferenceHelper.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  String? profile, name, email;
  getUserData() async {
    final authUser = FirebaseAuth.instance.currentUser;
    if (authUser != null) {
      profile = authUser.photoURL;
      name = authUser.displayName ?? "No Name";
      email = authUser.email ?? "No Email";

      await SharedPreferenceHelper().saveUserName(name!);
      await SharedPreferenceHelper().saveUserEmail(email!);
      if (profile != null) {
        await SharedPreferenceHelper().saveUserProfile(profile!);
      }
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getUserData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  padding: EdgeInsets.only(top: 45, left: 20, right: 20),
                  height: MediaQuery.of(context).size.height / 4.3,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 13, 162, 231),
                    borderRadius: BorderRadius.vertical(
                      bottom: Radius.elliptical(
                          MediaQuery.of(context).size.width, 105.0),
                    ),
                  ),
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 6.5),
                    child: Material(
                      elevation: 10.0,
                      borderRadius: BorderRadius.circular(60),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(60),
                        child: profile != null && profile!.isNotEmpty
                            ? Image.network(
                                profile!,
                                height: 120,
                                width: 120,
                                fit: BoxFit.cover,
                              )
                            : Image.asset(
                                "images/ultra-goku-fana-rt.jpg",
                                height: 120,
                                width: 120,
                                fit: BoxFit.cover,
                              ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 70.0),
                    child: Text(
                      name ?? "Name",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            infoTile(Icons.person, "Нэр", name ?? "No Name"),
            infoTile(Icons.email, "Email", email ?? "No Email"),
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, '/terms');
              },
              child: infoTile(Icons.description, "Нөхцөл ба болзол", ""),
            ),
            GestureDetector(
              onTap: () async {
                try {
                  await FirebaseAuth.instance.currentUser?.delete();
                  await SharedPreferenceHelper().clearUserData();
                  Navigator.pushReplacementNamed(context, '/register');
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Устгахын тулд дахин нэвтэрнэ үү.")));
                }
              },
              child: infoTile(Icons.delete, "Устгах", "Бүртгэл устгах"),
            ),
            GestureDetector(
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                await SharedPreferenceHelper().clearUserData();
                Navigator.pushReplacementNamed(context, '/login');
              },
              child: infoTile(Icons.logout, "Гарах", ""),
            ),
          ],
        ),
      ),
    );
  }

  Widget infoTile(IconData icon, String title, String subtitle) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
      child: Material(
        borderRadius: BorderRadius.circular(10),
        elevation: 2.0,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Row(
            children: [
              Icon(icon, color: Colors.black),
              SizedBox(width: 20.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16.0,
                          fontWeight: FontWeight.w600)),
                  if (subtitle.isNotEmpty)
                    Text(subtitle,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600)),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

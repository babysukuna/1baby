import 'package:flutter/material.dart';
import 'package:food/widget/widget.dart';
import 'details.dart';

class AllFoodTab extends StatefulWidget {
  const AllFoodTab({super.key});

  @override
  State<AllFoodTab> createState() => _AllFoodTabState();
}

class _AllFoodTabState extends State<AllFoodTab> {
  final List<Map<String, String>> foods = [
    {
      "image": "images/dump2.png",
      "title": "Соустай бууз",
      "subtitle": "Эрүүл хоол хүнс",
      "price": "₮20000",
      "description": "Амттай, эрүүл, халуун ногоо агуулсан бууз",
    },
    {
      "image": "images/dump1.png",
      "title": "Шөлтэй бууз",
      "subtitle": "Халуун ногоотой",
      "price": "₮25000",
      "description": "Шөлтэй, халуун ногоотой амттай бууз",
    },
    {
      "image": "images/pizza1.png",
      "title": "Итал пицца",
      "subtitle": "Зузаан бяслагтай",
      "price": "₮22000",
      "description": "Италийн уламжлалт пицца, зузаан бяслагтай",
    },
    {
      "image": "images/burger11.png",
      "title": "Чийз бургер",
      "subtitle": "Бяслагтай бургер",
      "price": "₮18000",
      "description": "Чийз бургерт зориулсан амтат хамтлаг",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
  const SizedBox(height: 10.0),

  Padding(
    padding: const EdgeInsets.only(left: 20.0),
    child: Text("Амтат хоолнууд", style: AppWidget.HeadLineTextFeildStyle()),
  ),

  const SizedBox(height: 6.0), 

  Padding(
    padding: const EdgeInsets.only(left: 20.0),
    child: Text("Гайхалтай хоол аваарай", style: AppWidget.LightTextFeildStyle()),
  ),

  const SizedBox(height: 10.0),


          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: foods.map((food) {
                return _buildHorizontalCard(
                  image: food['image']!,
                  title: food['title']!,
                  subtitle: food['subtitle']!,
                  price: food['price']!,
                  description: food['description']!, 
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => Details(
                          image: food['image']!,
                          title: food['title']!,
                          subtitle: food['subtitle']!,
                          price: int.parse(food['price']!.substring(1)), 
                          description: food['description']!, 
                        ),
                      ),
                    );
                  },
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 30.0),

          ...foods.map((food) => Column(
                children: [
                  _buildVerticalCard(
                    image: food['image']!,
                    title: food['title']!,
                    subtitle: food['subtitle']!,
                    price: food['price']!,
                    description: food['description']!, 
                  ),
                  const SizedBox(height: 30.0),
                ],
              )),
        ],
      ),
    );
  }

  Widget _buildHorizontalCard({
    required String image,
    required String title,
    required String subtitle,
    required String price,
    required String description,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        child: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(image, height: 150, width: 150, fit: BoxFit.cover),
                const SizedBox(height: 8),
                Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                Text(price, style: AppWidget.SemiBoldTextFeildStyle()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVerticalCard({
    required String image,
    required String title,
    required String subtitle,
    required String price,
    required String description,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Image.asset(image, height: 100, width: 100, fit: BoxFit.cover),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppWidget.SemiBoldTextFeildStyle()),
                    Text(subtitle, style: AppWidget.LightTextFeildStyle()),
                    Text(price, style: AppWidget.SemiBoldTextFeildStyle()),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

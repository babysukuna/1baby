import 'package:flutter/material.dart';

class AppWidget{
  static TextStyle boldTextFieldStyle(){
    return TextStyle(color: Colors.black,
         fontSize: 20.0,
         fontWeight:FontWeight.bold,
         fontFamily: 'Poppins');
  }
  static TextStyle HeadLineTextFeildStyle(){
    return TextStyle(color: Colors.black,
         fontSize: 25.0,
         fontWeight:FontWeight.bold,
         fontFamily: 'Poppins');
  
  }
   static TextStyle LightTextFeildStyle(){
    return TextStyle(color: Colors.black45,
         fontSize: 15.0,
         fontWeight:FontWeight.w500,
         fontFamily: 'Poppins');
  
  }
    static TextStyle SemiBoldTextFeildStyle(){
    return TextStyle(color: Colors.black,
         fontSize: 15.0,
         fontWeight:FontWeight.w700,
         fontFamily: 'Poppins');
  
  }
}